<?php
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'ProductController@index')->name('main');
Route::get('/запчасти_для_телевизоров', 'ProductController@index');

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();


/**
 * Page Routes
 */

Route::get('/о_нас', function () {
    return view('page/about');
})->name('about');

Route::get('/каталог', 'ProductController@getAllProduct')->name('catalog');

Route::get('/каталог/{part_types_id}', 'ProductController@getFullCategory')->name('category.show');



Route::get('/продукт', function () {
    return view('page/product');
});

Route::get('/карта', function () {
    return view('page/cart');
});

Route::get('/доставка', function () {
    return view('page/delivery');
})->name('delivery');

Route::get('/контакты', function () {
    return view('page/contacts');
})->name('contacts');


/**
 * Search Route
 */
Route::get('/search','SearchController@search');

/**
 * Search Route mobile link
 */
Route::get('/find','SearchController@getMobilePage')->name('search.mobile');

