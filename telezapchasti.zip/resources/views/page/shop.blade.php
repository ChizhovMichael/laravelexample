<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <title>Каталог</title>
    <meta name="description" content="Каталог">
    <meta name="keywords" content="Каталог">

    <!-- Headbase -->

    @include('includes.head')

    <link rel="stylesheet" href="{{ URL::asset('css/noUiSlider/noUiSlider.css') }}">
    <script src="{{ URL::asset('js/noUiSlider/noUiSlider.js') }}"></script>

</head>

<body>

    @include('includes.nav')
    @if ($agent->isDesktop())
    <div class="features">
        <div class="features__item">
            <div class="features__item__wrapp">
                <div class="char_icon"><img src="{{ asset('img/icon/char_1.png') }}" alt="Запчасти для телевизоров, продать телевизор +на запчасти, телевизор скупка, телезапчасти"></div>
                <div class="char_content">
                    <h6>Free Delivery</h6>
                    <p>from 50&nbsp;&#x20bd;</p>
                </div>
            </div>
        </div>
        <div class="features__item">
            <div class="features__item__wrapp">
                <div class="char_icon"><img src="{{ asset('img/icon/char_2.png') }}" alt="Запчасти для телевизоров, продать телевизор +на запчасти, телевизор скупка, телезапчасти"></div>
                <div class="char_content">
                    <h6>Free Delivery</h6>
                    <p>from 50&nbsp;&#x20bd;</p>
                </div>
            </div>
        </div>
        <div class="features__item">
            <div class="features__item__wrapp">
                <div class="char_icon"><img src="{{ asset('img/icon/char_3.png') }}" alt="Запчасти для телевизоров, продать телевизор +на запчасти, телевизор скупка, телезапчасти"></div>
                <div class="char_content">
                    <h6>Free Delivery</h6>
                    <p>from 50&nbsp;&#x20bd;</p>
                </div>
            </div>
        </div>
        <div class="features__item">
            <div class="features__item__wrapp">
                <div class="char_icon"><img src="{{ asset('img/icon/char_4.png') }}" alt="Запчасти для телевизоров, продать телевизор +на запчасти, телевизор скупка, телезапчасти"></div>
                <div class="char_content">
                    <h6>Free Delivery</h6>
                    <p>from 50&nbsp;&#x20bd;</p>
                </div>
            </div>
        </div>
    </div>
    @endif
    <div class="catalog">
        @if ($agent->isMobile())
        <div class="sorting__back"></div>
        <div class="sorting__wrapp">
        @endif
        <div class="sorting">

            @if ($agent->isMobile())
            <div class="sorting__caption">
                <div class="sorting__caption__item">
                    <h6>Фильтры</h6>
                </div>
                <a href="#" onclick="
                    event.preventDefault();
                    document.querySelector('.sorting__wrapp').classList.remove('active');
                    document.querySelector('.sorting__back').classList.remove('active')
                    "><img src="{{ asset('img/icon/cancel.svg') }}" alt="cancel"></a>
            </div>
            @endif

            <div class="sorting__item">
                <input type="checkbox" id="product" checked />
                <label for="product">
                    Запчасти
                    <img src="{{ asset('img/icon/chevron-arrow-down.svg') }}" alt="arrow">
                </label>
                <ul>
                    @foreach($navigations as $item)
                    <li>
                        <a href="{{ route('category.show', ['part_types_id' => $item->slug ]) }}" class="@if (Request::is('каталог/'.$item->slug )) active @endif">{{ $item->name }}</a>
                    </li>
                    @endforeach
                </ul>
            </div>
            <div class="sorting__item">
                <input type="checkbox" id="tv" checked />
                <label for="tv">
                    Бренд телевизора
                    <img src="{{ asset('img/icon/chevron-arrow-down.svg') }}" alt="arrow">
                </label>
                <ul>
                    @foreach($brand->slice(0, 7) as $item)
                        <li>
                            <div class="form-check">
                                <input class="form-check-input" data-form="brands-check" type="checkbox" @if(preg_match("/{$item->company}/i", $brands)) checked @endif value="{{ $item->company }}" id="{{ $item->company }}">
                                <span class="form-check-span"></span>
                                <label class="form-check-label" for="{{ $item->company }}">
                                    {{ $item->company }}
                                </label>
                            </div>
                        </li>
                    @endforeach
                    <div class="toggle__sorting">
                        @foreach($brand->slice(7) as $item)
                            <li>
                                <div class="form-check">
                                    <input class="form-check-input" data-form="brands-check" type="checkbox" @if(preg_match("/{$item->company}/i", $brands)) checked @endif value="{{ $item->company }}" id="{{ $item->company }}">
                                    <span class="form-check-span"></span>
                                    <label class="form-check-label" for="{{ $item->company }}">
                                        {{ $item->company }}
                                    </label>
                                </div>
                            </li>
                        @endforeach
                    </div>
                    <form id="brands-check" action="{!! urldecode(\Request::url()) !!}" method="GET" style="display: none;">
    
                        <input type="hidden" class="brands-check" name="brands" value="{{ $brands }}">
                    </form>
                </ul>
                <a href="#" class="toggle--content button__trigger"></a>
            </div>
            <div class="sorting__item">
                <input type="checkbox" id="price" checked />
                <label for="price">
                    Цена
                    <img src="{{ asset('img/icon/chevron-arrow-down.svg') }}" alt="arrow">
                </label>
                <ul>
                    <li>
                        <div class="price">
                            <span id="from">{{ $min }} &#x20bd;</span>
                            <span> - </span>
                            <span id="to">{{ $max }} &#x20bd;</span>
                        </div>
                        <div class="multi-range">
                            <input id="min" type="range" min="0" max="100" value="0" step="0.0001" />
                            <input id="max" type="range" min="0" max="100" value="100" step="0.0001" />
                        </div>
                    </li>
                </ul>

            </div>
            <div class="sorting__item">
                <input type="checkbox" id="category" checked />
                <label for="category">
                    Категория
                    <img src="{{ asset('img/icon/chevron-arrow-down.svg') }}" alt="arrow">
                </label>
                <ul>
                <li>
                        <a href="?stock=all" class="@if ($stock == null) active @endif">Вся продукция</a>
                    </li>
                    <li>
                        <a href="?stock=new" class="@if ($stock == 'new') active @endif">Новые поступления</a>
                    </li>
                    <li>
                        <a href="?stock=discount" class="@if ($stock == 'discount') active @endif">Акция</a>
                    </li>
                </ul>
            </div>
            <div class="sorting__item">
                <a href="{!! urldecode(\Request::url()) !!}" class="button__trigger">Очистить фильтры</a>
            </div>
        </div>
        @if ($agent->isMobile())
        </div>
        @endif
        <div class="container">
            <div class="container__sorting">

                @if ($agent->isMobile())
                <a href="#" class="trigger" onclick="
                event.preventDefault();
                document.querySelector('.sorting__wrapp').classList.add('active');
                document.querySelector('.sorting__back').classList.add('active')
                ">Фильтры</a>

                @endif

                <div class="dropdown">
                    <div class="dropdown__list">
                        <img src="{{ asset('img/icon/chevron-arrow-down.svg') }}" alt="Запчасти для телевизоров, продать телевизор +на запчасти, телевизор скупка, телезапчасти">
                        {!! $output !!}
                    </div>
                </div>
            </div>
            <div class="card" id="card">
                @foreach($part_types as $part)
                <div class="card__item shop">
                    <div class="product__item {{ $part->stock }}">
                        <div class="product_image">
                            <img src="/img/products/{{ $part->company_id }}/{{ $part->matrix_id }}/m{{ $part->part_img_name }}" alt="Запчасти для телевизоров, {{ $part->parttype_type }} {{ $part->part_model }} c телевизора {{ $part->company }} {{ $part->tv_model }}">
                        </div>
                        <div class="product_content">
                            <div class="product_price">
                                <h6>
                                    {{ $part->part_cost }}&nbsp;&#x20bd;
                                    <span>{{ $part->price }}</span>
                                </h6>
                            </div>
                            <div class="product_name">
                                <p>{{ $part->company }} {{ $part->tv_model }}</p>
                                <a href="#">{{ ltrim($part->part_model) }}</a>
                            </div>
                            <div class="product_extras">
                                <button class="product_cart_button">
                                    <img src="{{ asset('img/icon/shopping-bag.svg') }}" alt="Купить">
                                </button>
                            </div>
                        </div>
                        <ul class="product_marks">
                            <li class="product_marks__item product_discount">-{{ $part->percent }}%</li>
                            <li class="product_marks__item product_new">new</li>
                        </ul>
                    </div>
                </div>
                @endforeach
            </div>
            @if ($agent->isDesktop())
            {!! urldecode($part_types->links()) !!}
            @else
            {!! urldecode($part_types->onEachSide(1)->links()) !!}
            @endif
        </div>
    </div>

    @include('includes.footer')

</body>

</html>