<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <title>Телезапчасти</title>
    <meta name="description" content="Телезапчасти">
    <meta name="keywords" content="Телезапчасти">

    <!-- Headbase -->

    @include('includes.head')

    <link rel="stylesheet" href="{{ URL::asset('css/flickity/flickity.css') }}">
    <script src="{{ URL::asset('js/flickity/flickity.js') }}"></script>

</head>

<body>
    @include('includes.nav')

    <section class="search__mobile">
        <div class="main__item">
            <div class="main__item__search">
                <form action="#" method="POST">
                    <div class="form-label-group">
                        <input type="text" id="search" name="search" value="" class="form-control" placeholder="Поиск по продукции">
                        <label for="search">Поиск по продукции</label>
                    </div>
                    <div class="dropdown">
                        <div class="dropdown__list">
                            <span class="dropdown_placeholder">
                                Все категории
                            </span>
                            <ul class="dropdown__list__ul">
                                <li><a class="clc" href="#">Все категории</a></li>
                                @foreach($navigations as $item)
                                <li><a class="clc" href="#">{{ $item->name }}</a></li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                </form>
            </div>

            <div class="result__search">
                <div class="result__wrapp">
                    <div class="container">
                        <div class="noscroll">
                            <div class="article" id="tbody">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>

</body>

</html>