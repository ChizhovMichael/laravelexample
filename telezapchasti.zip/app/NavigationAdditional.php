<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NavigationAdditional extends Model
{
    //
    protected $fillable = [
        'navigation_id',
    ];
}
