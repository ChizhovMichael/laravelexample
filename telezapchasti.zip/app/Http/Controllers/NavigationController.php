<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Navigation;
use App\Product;

/***************
 * Навигационный раздел
 * 1. Навигация
 * 2. Вывод всех брендов в зависимости от количества товаров
 ***********/

trait NavigationController
{
    //

    /**
     * Navigation function to display 
     * categories of main and additional for different pages
     */
    public function navigation()
    {
        $navigations = Navigation::with('navigation_items')
        ->get();

        return $navigations;
    }


    /**
     * Brand
     * Get All brand with sorting for count products
     * the updated GET parameters
     */
    public function getAllBrand()
    {


        $brands = Product::selectRaw('count(company_id) AS cnt, company')
            ->groupBy('company_id')
            ->orderBy('cnt', 'DESC')
            ->leftJoin('companies', 'products.company_id', '=', 'companies.id')->get();


        return $brands;
    }
}
