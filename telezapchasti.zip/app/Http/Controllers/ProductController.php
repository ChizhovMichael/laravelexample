<?php

namespace App\Http\Controllers;

use App\Product;
use App\Company;
use Illuminate\Http\Request;
use App\Navigation;
use App\Http\Controllers\NavigationController;
use Illuminate\Support\Facades\DB;

/**
 * Функции сортировки
 * 1. Sorting - сортировка по названию, цене
 * 2. Stock  - сортировка по новинкам, акциям
 * 3. Brand - сортировка по брендам
 * 
 */

class ProductController extends Controller
{
    //
    /**
     * Function for main page. Get item
     *
     * @return \Illuminate\Http\Response
     */

    use NavigationController;

    public function index()
    {
        return view('welcome', [
            'products_main'     =>  $this->getProduct('3', NULL, 10),
            'products_power'    =>  $this->getProduct('2', NULL, 10),
            'products_led'      =>  $this->getProduct('19', '20', 10),
            'products_new'      =>  $this->getStockProduct('new', 10),
            'products_discount' =>  $this->getStockProduct('discount', 10),
            'navigations'       =>  $this->navigation(),
        ]);
    }

    /**
     * the output function of products with images 
     * and all related tables, for example, company name, 
     * promotional table, matrix name, etc.
     */
    private function getProduct($category, $categoryAdd = NULL, $pag)
    {

        $products = Product::join('companies', 'products.company_id', '=', 'companies.id')
            ->join('tvs', 'products.tv_id', '=', 'tvs.id')
            ->join('part_types', 'products.parttype_id', '=', 'part_types.id')
            ->leftJoin('part_img', function ($join) {
                $join->on('products.id', '=', 'part_img.part_id')
                    ->where('part_img_main', '=', '1');
            })
            ->leftJoin('stocks', 'products.id', '=', 'stocks.product_id')
            ->where('products.parttype_id', '=', $category)
            ->orWhere('products.parttype_id', '=', $categoryAdd)
            ->paginate($pag);

        return $products;
    }


    private function getStockProduct($stock, $pag)
    {
        $products = Product::join('companies', 'products.company_id', '=', 'companies.id')
            ->join('tvs', 'products.tv_id', '=', 'tvs.id')
            ->join('part_types', 'products.parttype_id', '=', 'part_types.id')
            ->leftJoin('part_img', function ($join) {
                $join->on('products.id', '=', 'part_img.part_id')
                    ->where('part_img_main', '=', '1');
            })
            ->leftJoin('stocks', 'products.id', '=', 'stocks.product_id')
            ->where('stocks.stock', '=', $stock)
            ->paginate($pag);

        return $products;
    }


    public function getAllProduct(Request $request)
    {

        $output = $this->sortingGet($request->sort);
        $stock = $this->stockGet($request->stock);
        $brands = explode(',', $request->brands);


        $part_types = Product::join('companies', 'products.company_id', '=', 'companies.id')
            ->leftJoin('tvs', 'products.tv_id', '=', 'tvs.id')
            ->leftJoin('part_types', 'products.parttype_id', '=', 'part_types.id')
            ->leftJoin('part_img', function ($join) {
                $join->on('products.id', '=', 'part_img.part_id')
                    ->where('part_img_main', '=', '1');
            })
            ->leftJoin('stocks', 'products.id', '=', 'stocks.product_id')
            ->orderBy($output['name'], $output['sort']);


        // Сортировка по категориям
        $part_types = $stock != NULL ? $part_types->where('stocks.stock', '=', $stock) : $part_types;

        // Сортировка по компаниям
        $part_types = $request->brands != NUll ? $part_types->whereIn('companies.company', $brands) : $part_types;

       
        // Минимальная максимальная цена пока берет совместно с пагинацией         
        $min = $part_types->min('part_cost');
        $max = $part_types->max('part_cost');
        

        // Вывод c пагинацией в 12
        $part_types = $part_types->paginate(12);


        return view('page/shop', [
            'part_types'    => $part_types->appends([
                'sort' => $request->sort,
                'stock' => $request->stock,
                'brands' => $request->brands
            ]),
            'navigations'   => $this->navigation(),
            'output'        => $output['output'],
            'stock'         => $stock,
            'brand'         => $this->getAllBrand(),
            'min'           => $min,
            'max'           => $max,
            'brands'        => $request->brands
        ]);
    }




    /**
     * We get the full category of products 
     * belonging to the selected category
     */
    public function getFullCategory($part_types_id, Request $request)
    {

        $output = $this->sortingGet($request->sort);
        $stock = $this->stockGet($request->stock);
        $brands = explode(',', $request->brands);
        
        $additional_id = [];

        $navigation = Navigation::join('navigation_additionals', 'navigations.id', '=', 'navigation_additionals.navigation_id')
            ->selectRaw('count(*) AS cnt, additional_id')->groupBy('additional_id')            
            ->where('navigations.slug', '=', $part_types_id)
            ->orWhere('navigation_additionals.additional_slug', '=', $part_types_id)
            ->orderBy('cnt', 'DESC')->get();

        foreach ($navigation as $item) {
            array_push($additional_id, $item->additional_id);
        }

        $part_types = Product::whereIn('parttype_id', $additional_id);

        $part_types = $part_types->leftJoin('companies', 'products.company_id', '=', 'companies.id')
            ->leftJoin('tvs', 'products.tv_id', '=', 'tvs.id')
            ->leftJoin('part_img', function ($join) {
                $join->on('products.id', '=', 'part_img.part_id')
                    ->where('part_img_main', '=', '1');
            })
            ->leftJoin('part_types', 'part_types.id', '=', 'products.parttype_id')
            ->leftJoin('stocks', 'products.id', '=', 'stocks.product_id')
            ->orderBy($output['name'], $output['sort']);


        // Сортировка по категориям
        $part_types = $stock != NULL ? $part_types->where('stocks.stock', '=', $stock) : $part_types;

        // Сортировка по компаниям
        $part_types = $request->brands != NUll ? $part_types->whereIn('companies.company', $brands) : $part_types;

        // Минимальная максимальная цена пока берет совместно с пагинацией         
        $min = $part_types->min('part_cost');
        $max = $part_types->max('part_cost');
        

        // Вывод c пагинацией в 12
        $part_types = $part_types->paginate(12);


        return view('page/shop', [
            'part_types'    => $part_types->appends([
                'sort' => $request->sort,
                'stock' => $request->stock,
                'brands' => $request->brands
            ]),
            'navigations'   => $this->navigation(),
            'output'        => $output['output'],
            'stock'         => $stock,
            'brand'         => $this->getAllBrand(),
            'min'           => $min,
            'max'           => $max,
            'brands'        => $request->brands
        ]);
    }

    /**
     * Sorting
     * We get the sorting with updated GET parameters 
     * and span.innerText for products section
     */
    private function sortingGet($param)
    {
        $sorting = array(
            ['nameAZ', 'По названию &darr;'],
            ['nameZA', 'По названию &uarr;'],
            ['priceLow', 'По цене &darr;'],
            ['priceHigh', 'По цене &uarr;']
        );

        switch ($param) {
            case 'nameAZ':
                $name = 'part_model';
                $sort = 'asc';
                $value = 'По названию &darr;';
                break;
            case 'nameZA':
                $name = 'part_model';
                $sort = 'desc';
                $value = 'По названию &uarr;';
                break;
            case 'priceLow':
                $name = 'part_cost';
                $sort = 'asc';
                $value = 'По цене &darr;';
                break;
            case 'priceHigh':
                $name = 'part_cost';
                $sort = 'desc';
                $value = 'По цене &uarr;';
                break;
            default:
                $name = 'products.id';
                $sort = 'asc';
                $value = 'Сортировать';
        }

        $output =   '<span class="dropdown_placeholder">';
        $output .= $value;
        $output .=  '</span>';
        $output .=  '<ul class="dropdown__list__ul" id="sortingProduct">';
        foreach ($sorting as $item) {
            $output .= '<li><a class="sort-link" href="?sort=' . $item[0] . '">' . $item[1] . '</a></li>';
        }
        $output .=  '</ul>';

        $result['output'] = $output;
        $result['name'] = $name;
        $result['sort'] = $sort;

        return $result;
    }

    /**
     * Stock
     * We get the sort by the stock parameter with 
     * the updated GET parameters
     */
    private function stockGet($param)
    {
        switch ($param) {
            case 'all':
                $stock = NULL;
                break;
            case 'new':
                $stock = 'new';
                break;
            case 'discount':
                $stock = 'discount';
                break;
            default:
                $stock = NULL;
        }

        return $stock;
    }

    
    
}
