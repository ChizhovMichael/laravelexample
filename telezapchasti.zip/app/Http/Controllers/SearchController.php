<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\NavigationController;
use App\Product;

class SearchController extends Controller
{
    //

    use NavigationController;

    public function search(Request $request)
    {

        if ($request->ajax()) {
            $output = "";

            $part_types = Product::join('companies', 'products.company_id', '=', 'companies.id')
                ->join('tvs', 'products.tv_id', '=', 'tvs.id')
                ->join('part_types', 'products.parttype_id', '=', 'part_types.id')
                ->where('part_model', 'LIKE', '%' . $request->search . "%")
                ->paginate(8);

            if ($request->search == '')
                return $output;


            if ($part_types) {
                foreach ($part_types as $part) {
                    $output .= '<div class="articles">' .
                        '<div class="title">' .
                        '<a href="/каталог/артикул/' . $part->part_link . '">' . $part->parttype_type . ' ' . $part->part_model . '</a>' .
                        '<p>' . $part->part_cost . '</p>' .
                        '</div>' .
                        '<div class="description">' .
                        '<p>' . $part->company . ' ' . $part->tv_model . '</p>' .
                        '</div>' .
                        '</div>';
                }
                return $output;
            }
        }
    }


    public function getMobilePage()
    {
        return view('page/search', [
            'navigations'       =>  $this->navigation(),
        ]);
    }
}
