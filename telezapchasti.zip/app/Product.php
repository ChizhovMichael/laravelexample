<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    //
    protected $fillable = [
        'part_model', 
        'part_comment', 
        'part_comment_for_client',
        'part_link',
        'part_cost',
        'part_count',
        'parttype_id',
        'ebay_id',
        'matrix_id',
        'tv_id',
        'corp_id',
        'part_status',
        'part_for_elements',
        'part_return',
        'part_condition',
        'group_id',
        'searched_keyword',
        'primaryCategory',
        'itemTitle',
        'itemDescription',
        'startPrice',
        'listingDuration',
        'itemID',
        'siteID'
    ];

    public function products_new()
    {
        return $this->hasMany('App\Stock');
    }
}
