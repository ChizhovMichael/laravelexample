<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateNavigationAdditionalsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('navigation_additionals', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('navigation_id')->unsigned();
            $table->foreign('navigation_id')->references('id')->on('navigations')->onDelete('cascade');
            $table->integer('additional_id')->unsigned();
            $table->string('additional_name');
            $table->string('additional_slug')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('navigation_additionals');
    }
}
