<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <title>Каталог</title>
    <meta name="description" content="Каталог">
    <meta name="keywords" content="Каталог">

    <!-- Headbase -->

    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/flickity/flickity.css')); ?>">
    <script src="<?php echo e(URL::asset('js/flickity/flickity.js')); ?>"></script>

</head>

<body>

    <?php echo $__env->make('includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="single_product">



        <!-- Images -->

        <ul class="image_list">
            <li data-image="<?php echo e(asset('img/m1513630340d.jpg')); ?>" class="image_list_li">
                <img src="<?php echo e(asset('img/m1513630340d.jpg')); ?>" alt="">
            </li>
            <li data-image="<?php echo e(asset('img/m1513630340d.jpg')); ?>" class="image_list_li">
                <img src="<?php echo e(asset('img/m1513630340d.jpg')); ?>" alt="">
            </li>
            <li data-image="хуй" class="image_list_li">
                <img src="<?php echo e(asset('img/m1513630340d.jpg')); ?>" alt="">
            </li>
        </ul>


        <!-- Selected Image -->

        <div class="image_selected">
            <img src="<?php echo e(asset('img/m1513630340d.jpg')); ?>" alt="" class="image_list_cont">
        </div>


        <!-- Description -->

        <div class="product_description">
            <span>Laptops</span>
            <h1>MacBook Air 13</h1>
            
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas fermentum. laoreet turpis, nec sollicitudin dolor cursus at. Maecenas aliquet, dolor a faucibus efficitur, nisi tellus cursus urna, eget dictum lacus turpis.</p>
            
            <span class="found">В наличие</span>
            <div>
                <form action="#">
                    <div>

                        <!-- Product Quantity -->
                        <div class="product_quantity">
                            <span>Количество: </span>
                            <input id="quantity_input" type="text" pattern="[0-9]*" value="1">
                            <div class="quantity_buttons">
                                <div id="quantity_inc_button" class="quantity_inc quantity_control">
                                    <img src="<?php echo e(asset('img/icon/chevron-arrow-up.svg')); ?>" alt="">
                                </div>
                                <div id="quantity_dec_button" class="quantity_dec quantity_control">
                                    <img src="<?php echo e(asset('img/icon/chevron-arrow-down.svg')); ?>" alt="">
                                </div>
                            </div>
                        </div>

                    </div>

                    <h5>2000&nbsp;&#x20bd;</h5>
                    <div class="button_container">
                        <button class="product_cart_button">
                            <img src="<?php echo e(asset('img/icon/shopping-bag.svg')); ?>" alt="Запчасти для телевизоров, название товара + артикул">
                        </button>

                    </div>

                </form>
            </div>
        </div>




    </div>

    <div class="hot">
        <div class="hot__caption">
            <h4>Такие же товары</h4>
        </div>
        <div class="card">
            <div class="card__item">
                <div class="product__item discount">
                    <div class="product_image">
                        <img src="<?php echo e(asset('img/m1513630340d.jpg')); ?>" alt="Запчасти для телевизоров, название товара + артикул">
                    </div>
                    <div class="product_content">
                        <div class="product_price">
                            <h6>
                                379&nbsp;&#x20bd;
                                <span>225&nbsp;&#x20bd;</span>
                            </h6>
                        </div>
                        <div class="product_name">
                            <p>lorem ipsum</p>
                            <a href="#">Sony MDRZX310W</a>
                        </div>
                        <div class="product_extras">
                            <button class="product_cart_button">
                                <img src="<?php echo e(asset('img/icon/shopping-bag.svg')); ?>" alt="Купить">
                            </button>
                        </div>
                    </div>
                    <ul class="product_marks">
                        <li class="product_marks__item product_discount">-25%</li>
                        <li class="product_marks__item product_new">new</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="slider-full">
        <div class="carousel" data-flickity='{ "contain": true, "prevNextButtons": false, "pageDots": false, "adaptiveHeight": true, "fade": true, "setGallerySize": false, "autoPlay": 3000 }'>
            <div class="carousel-cell">

            </div>
            <div class="carousel-cell">

            </div>
            <div class="carousel-cell">

            </div>
        </div>
    </div>

    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH E:\telezapchasti\resources\views/page/product.blade.php ENDPATH**/ ?>