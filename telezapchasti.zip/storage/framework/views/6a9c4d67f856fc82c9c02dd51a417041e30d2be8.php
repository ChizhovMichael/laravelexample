<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <title>Карта</title>
    <meta name="description" content="Карта">
    <meta name="keywords" content="Карта">

    <!-- Headbase -->

    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>

    <?php echo $__env->make('includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="shopping">
        <h3>Сумма покупки</h3>

        <?php if($agent->isDesktop()): ?>

        <table class="shopping__cart">
            <tr>
                <th class="shopping__cart__caption"></th>
                <th>
                    <p>Название</p>
                </th>
                <th>
                    <p>Количество</p>
                </th>
                <th>
                    <p>Цена</p>
                </th>
                <th>
                    <p>Сумма</p>
                </th>
            </tr>
            <tr>
                <td class="shopping__cart__image"><img src="<?php echo e(asset('img/m1513630340d.jpg')); ?>" alt="Запчасти для телевизоров, название товара + артикул"></td>
                <td>
                    <h6>MacBook Air 13</h6>
                </td>
                <td>
                    <h6>MacBook Air 13</h6>
                </td>
                <td>
                    <h6>MacBook Air 13</h6>
                </td>
                <td>
                    <h6>MacBook Air 13</h6>
                </td>
            </tr>
            <tr>
                <td>
                    <hr>
                </td>
            </tr>
            <tr>
                <td class="shopping__cart__image"><img src="<?php echo e(asset('img/m1513630340d.jpg')); ?>" alt="Запчасти для телевизоров, название товара + артикул"></td>
                <td>
                    <h6>MacBook Air 13</h6>
                </td>
                <td>
                    <h6>MacBook Air 13</h6>
                </td>
                <td>
                    <h6>MacBook Air 13</h6>
                </td>
                <td>
                    <h6>MacBook Air 13</h6>
                </td>
            </tr>
        </table>
        <table class="shopping__cart">
            <tr>
                <td class="shopping__cart__image"></td>
                <td></td>
                <td></td>
                <td>
                    <p>Сумма заказа:</p>
                </td>
                <td>
                    <h6>MacBook Air 13</h6>
                </td>
            </tr>
        </table>

        <?php else: ?>

        <div class="shopping__cart">
            <div class="shopping__wrapp">
                <div class="shopping__cart__item shopping__cart__image">
                    <img src="<?php echo e(asset('img/m1513630340d.jpg')); ?>" alt="Запчасти для телевизоров, название товара + артикул">
                </div>
                <div class="shopping__cart__item">
                    <h6>MacBook Air 13</h6>
                </div>
                <div class="shopping__cart__item">
                    <p>1990&nbsp;&#x20bd; за 1 шт</p>
                </div>
                <div class="shopping__cart__item">
                    <p>2шт</p>
                </div>
                <div class="shopping__cart__item">
                    <h6>Сумма: 3980&nbsp;&#x20bd;</h6>
                </div>
            </div>
            <div class="shopping__wrapp">
                <div class="shopping__cart__item shopping__cart__image">
                    <img src="<?php echo e(asset('img/m1513630340d.jpg')); ?>" alt="Запчасти для телевизоров, название товара + артикул">
                </div>
                <div class="shopping__cart__item">
                    <h6>MacBook Air 13</h6>
                </div>
                <div class="shopping__cart__item">
                    <p>1990&nbsp;&#x20bd; за 1 шт</p>
                </div>
                <div class="shopping__cart__item">
                    <p>2шт</p>
                </div>
                <div class="shopping__cart__item">
                    <h6>Сумма: 3980&nbsp;&#x20bd;</h6>
                </div>
            </div>
        </div>
        <div class="shopping__cart">
            <h6>Сумма покупки: 3980&nbsp;&#x20bd;</h6>
        </div>

        <?php endif; ?>

        <div class="button_container">
            <button class="product_cart_button">
                <img src="<?php echo e(asset('img/icon/shopping-bag.svg')); ?>" alt="Запчасти для телевизоров, название товара + артикул">
            </button>

        </div>
    </div>

    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH E:\telezapchasti\resources\views/page/cart.blade.php ENDPATH**/ ?>