<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <title>Каталог</title>
    <meta name="description" content="Каталог">
    <meta name="keywords" content="Каталог">

    <!-- Headbase -->

    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <link rel="stylesheet" href="<?php echo e(URL::asset('css/noUiSlider/noUiSlider.css')); ?>">
    <script src="<?php echo e(URL::asset('js/noUiSlider/noUiSlider.js')); ?>"></script>

</head>

<body>

    <?php echo $__env->make('includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if($agent->isDesktop()): ?>
    <div class="features">
        <div class="features__item">
            <div class="features__item__wrapp">
                <div class="char_icon"><img src="<?php echo e(asset('img/icon/char_1.png')); ?>" alt="Запчасти для телевизоров, продать телевизор +на запчасти, телевизор скупка, телезапчасти"></div>
                <div class="char_content">
                    <h6>Free Delivery</h6>
                    <p>from 50&nbsp;&#x20bd;</p>
                </div>
            </div>
        </div>
        <div class="features__item">
            <div class="features__item__wrapp">
                <div class="char_icon"><img src="<?php echo e(asset('img/icon/char_2.png')); ?>" alt="Запчасти для телевизоров, продать телевизор +на запчасти, телевизор скупка, телезапчасти"></div>
                <div class="char_content">
                    <h6>Free Delivery</h6>
                    <p>from 50&nbsp;&#x20bd;</p>
                </div>
            </div>
        </div>
        <div class="features__item">
            <div class="features__item__wrapp">
                <div class="char_icon"><img src="<?php echo e(asset('img/icon/char_3.png')); ?>" alt="Запчасти для телевизоров, продать телевизор +на запчасти, телевизор скупка, телезапчасти"></div>
                <div class="char_content">
                    <h6>Free Delivery</h6>
                    <p>from 50&nbsp;&#x20bd;</p>
                </div>
            </div>
        </div>
        <div class="features__item">
            <div class="features__item__wrapp">
                <div class="char_icon"><img src="<?php echo e(asset('img/icon/char_4.png')); ?>" alt="Запчасти для телевизоров, продать телевизор +на запчасти, телевизор скупка, телезапчасти"></div>
                <div class="char_content">
                    <h6>Free Delivery</h6>
                    <p>from 50&nbsp;&#x20bd;</p>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="catalog">
        <?php if($agent->isMobile()): ?>
        <div class="sorting__back"></div>
        <div class="sorting__wrapp">
        <?php endif; ?>
        <div class="sorting">

            <?php if($agent->isMobile()): ?>
            <div class="sorting__caption">
                <div class="sorting__caption__item">
                    <h6>Фильтры</h6>
                </div>
                <a href="#" onclick="
                    event.preventDefault();
                    document.querySelector('.sorting__wrapp').classList.remove('active');
                    document.querySelector('.sorting__back').classList.remove('active')
                    "><img src="<?php echo e(asset('img/icon/cancel.svg')); ?>" alt="cancel"></a>
            </div>
            <?php endif; ?>

            <div class="sorting__item">
                <input type="checkbox" id="product" checked />
                <label for="product">
                    Запчасти
                    <img src="<?php echo e(asset('img/icon/chevron-arrow-down.svg')); ?>" alt="arrow">
                </label>
                <ul>
                    <?php $__currentLoopData = $navigations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('category.show', ['part_types_id' => $item->slug ])); ?>" class="<?php if(Request::is('каталог/'.$item->slug )): ?> active <?php endif; ?>"><?php echo e($item->name); ?></a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="sorting__item">
                <input type="checkbox" id="tv" checked />
                <label for="tv">
                    Бренд телевизора
                    <img src="<?php echo e(asset('img/icon/chevron-arrow-down.svg')); ?>" alt="arrow">
                </label>
                <ul>
                    <?php $__currentLoopData = $brand->slice(0, 7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="form-check">
                                <input class="form-check-input" data-form="brands-check" type="checkbox" <?php if(preg_match("/{$item->company}/i", $brands)): ?> checked <?php endif; ?> value="<?php echo e($item->company); ?>" id="<?php echo e($item->company); ?>">
                                <span class="form-check-span"></span>
                                <label class="form-check-label" for="<?php echo e($item->company); ?>">
                                    <?php echo e($item->company); ?>

                                </label>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="toggle__sorting">
                        <?php $__currentLoopData = $brand->slice(7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <div class="form-check">
                                    <input class="form-check-input" data-form="brands-check" type="checkbox" <?php if(preg_match("/{$item->company}/i", $brands)): ?> checked <?php endif; ?> value="<?php echo e($item->company); ?>" id="<?php echo e($item->company); ?>">
                                    <span class="form-check-span"></span>
                                    <label class="form-check-label" for="<?php echo e($item->company); ?>">
                                        <?php echo e($item->company); ?>

                                    </label>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <form id="brands-check" action="<?php echo urldecode(\Request::url()); ?>" method="GET" style="display: none;">
    
                        <input type="hidden" class="brands-check" name="brands" value="<?php echo e($brands); ?>">
                    </form>
                </ul>
                <a href="#" class="toggle--content button__trigger"></a>
            </div>
            <div class="sorting__item">
                <input type="checkbox" id="price" checked />
                <label for="price">
                    Цена
                    <img src="<?php echo e(asset('img/icon/chevron-arrow-down.svg')); ?>" alt="arrow">
                </label>
                <ul>
                    <li>
                        <div class="price">
                            <span id="from"><?php echo e($min); ?> &#x20bd;</span>
                            <span> - </span>
                            <span id="to"><?php echo e($max); ?> &#x20bd;</span>
                        </div>
                        <div class="multi-range">
                            <input id="min" type="range" min="0" max="100" value="0" step="0.0001" />
                            <input id="max" type="range" min="0" max="100" value="100" step="0.0001" />
                        </div>
                    </li>
                </ul>

            </div>
            <div class="sorting__item">
                <input type="checkbox" id="category" checked />
                <label for="category">
                    Категория
                    <img src="<?php echo e(asset('img/icon/chevron-arrow-down.svg')); ?>" alt="arrow">
                </label>
                <ul>
                <li>
                        <a href="?stock=all" class="<?php if($stock == null): ?> active <?php endif; ?>">Вся продукция</a>
                    </li>
                    <li>
                        <a href="?stock=new" class="<?php if($stock == 'new'): ?> active <?php endif; ?>">Новые поступления</a>
                    </li>
                    <li>
                        <a href="?stock=discount" class="<?php if($stock == 'discount'): ?> active <?php endif; ?>">Акция</a>
                    </li>
                </ul>
            </div>
            <div class="sorting__item">
                <a href="<?php echo urldecode(\Request::url()); ?>" class="button__trigger">Очистить фильтры</a>
            </div>
        </div>
        <?php if($agent->isMobile()): ?>
        </div>
        <?php endif; ?>
        <div class="container">
            <div class="container__sorting">

                <?php if($agent->isMobile()): ?>
                <a href="#" class="trigger" onclick="
                event.preventDefault();
                document.querySelector('.sorting__wrapp').classList.add('active');
                document.querySelector('.sorting__back').classList.add('active')
                ">Фильтры</a>

                <?php endif; ?>

                <div class="dropdown">
                    <div class="dropdown__list">
                        <img src="<?php echo e(asset('img/icon/chevron-arrow-down.svg')); ?>" alt="Запчасти для телевизоров, продать телевизор +на запчасти, телевизор скупка, телезапчасти">
                        <?php echo $output; ?>

                    </div>
                </div>
            </div>
            <div class="card" id="card">
                <?php $__currentLoopData = $part_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card__item shop">
                    <div class="product__item <?php echo e($part->stock); ?>">
                        <div class="product_image">
                            <img src="/img/products/<?php echo e($part->company_id); ?>/<?php echo e($part->matrix_id); ?>/m<?php echo e($part->part_img_name); ?>" alt="Запчасти для телевизоров, <?php echo e($part->parttype_type); ?> <?php echo e($part->part_model); ?> c телевизора <?php echo e($part->company); ?> <?php echo e($part->tv_model); ?>">
                        </div>
                        <div class="product_content">
                            <div class="product_price">
                                <h6>
                                    <?php echo e($part->part_cost); ?>&nbsp;&#x20bd;
                                    <span><?php echo e($part->price); ?></span>
                                </h6>
                            </div>
                            <div class="product_name">
                                <p><?php echo e($part->company); ?> <?php echo e($part->tv_model); ?></p>
                                <a href="#"><?php echo e(ltrim($part->part_model)); ?></a>
                            </div>
                            <div class="product_extras">
                                <button class="product_cart_button">
                                    <img src="<?php echo e(asset('img/icon/shopping-bag.svg')); ?>" alt="Купить">
                                </button>
                            </div>
                        </div>
                        <ul class="product_marks">
                            <li class="product_marks__item product_discount">-<?php echo e($part->percent); ?>%</li>
                            <li class="product_marks__item product_new">new</li>
                        </ul>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php if($agent->isDesktop()): ?>
            <?php echo urldecode($part_types->links()); ?>

            <?php else: ?>
            <?php echo urldecode($part_types->onEachSide(1)->links()); ?>

            <?php endif; ?>
        </div>
    </div>

    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH E:\telezapchasti\resources\views/page/shop.blade.php ENDPATH**/ ?>