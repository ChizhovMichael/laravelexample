<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <title>Телезапчасти</title>
    <meta name="description" content="Телезапчасти">
    <meta name="keywords" content="Телезапчасти">

    <!-- Headbase -->

    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <link rel="stylesheet" href="<?php echo e(URL::asset('css/flickity/flickity.css')); ?>">
    <script src="<?php echo e(URL::asset('js/flickity/flickity.js')); ?>"></script>

</head>

<body>
    <?php echo $__env->make('includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="search__mobile">
        <div class="main__item">
            <div class="main__item__search">
                <form action="#" method="POST">
                    <div class="form-label-group">
                        <input type="text" id="search" name="search" value="" class="form-control" placeholder="Поиск по продукции">
                        <label for="search">Поиск по продукции</label>
                    </div>
                    <div class="dropdown">
                        <div class="dropdown__list">
                            <span class="dropdown_placeholder">
                                Все категории
                            </span>
                            <ul class="dropdown__list__ul">
                                <li><a class="clc" href="#">Все категории</a></li>
                                <?php $__currentLoopData = $navigations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a class="clc" href="#"><?php echo e($item->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>

            <div class="result__search">
                <div class="result__wrapp">
                    <div class="container">
                        <div class="noscroll">
                            <div class="article" id="tbody">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>

</body>

</html><?php /**PATH E:\telezapchasti\resources\views/page/search.blade.php ENDPATH**/ ?>