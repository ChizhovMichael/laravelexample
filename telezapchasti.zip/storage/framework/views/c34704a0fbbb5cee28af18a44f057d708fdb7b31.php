<footer>
	<div class="footer__item">
		<div class="footer_column footer_contact">
			<div class="logo_container">
				<div class="logo">
					<img src="<?php echo e(asset('img/icon/logo.svg')); ?>" alt="Запчасти для телевизоров, Телезапчасти">
					<h3><span>tele</span>Zapchasti</h3>
				</div>
			</div>
			<h5>Есть вопросы? Звоните нам 24/7</h5>
			<a href="tel:" class="phone">+38 068 005 3570</a>
		</div>
	</div>
	<div class="footer__item">
		<h6>Меню</h6>
		<a href="#">
			Запчасти для ЖК ТВ
		</a>
		<a href="#">
			Запчасти для мониторов
		</a>
		<a href="#">
			Запчасти для ноутбуков
		</a>
		<a href="#">
			О нас
		</a>
		<a href="#">
			Доставка
		</a>
		<a href="#">
			Политика конфидициальности
		</a>
		<a href="#">
			Правила сайта
		</a>
	</div>
	<div class="footer__item">
		<div class="contacts__item">
			<h6>Контакты</h6>
			<p>Санкт-Петербург, г. Колпино, ул. Пролетарская, д. 60, строение 1</p>
		</div>
		<div class="contacts__item">
			<h6>Телефоны</h6>
			<p>+7 911 999 99 99</p>
			<p>+7 911 999 99 99</p>
		</div>
	</div>
	<div class="footer__item">
		<div class="contacts__item">
			<h6>Почта для связи</h6>
			<a href="mailto:">info@telezapchasti.ru</a>
			<a href="mailto:">info@telezapchasti.ru</a>
		</div>
	</div>
</footer>
<div class="copyright">
	<p class="copyright__item">Copyright © Forever Telezapchasti. All Rights Reserved</p>
	<div class="copyright__item">
		<ul>
			<li><img src="<?php echo e(asset('img/icon/logos_1.png')); ?>" alt="Запчасти для телевизоров, покупка masterCard"></li>
			<li><img src="<?php echo e(asset('img/icon/logos_2.png')); ?>" alt="Запчасти для телевизоров, покупка Visa"></li>
			<li><img src="<?php echo e(asset('img/icon/logos_3.png')); ?>" alt="Запчасти для телевизоров, покупка PayPal"></li>
			<li><img src="<?php echo e(asset('img/icon/logos_4.png')); ?>" alt="Запчасти для телевизоров, покупка masterCard"></li>
		</ul>
	</div>
</div><?php /**PATH E:\telezapchasti\resources\views/includes/footer.blade.php ENDPATH**/ ?>