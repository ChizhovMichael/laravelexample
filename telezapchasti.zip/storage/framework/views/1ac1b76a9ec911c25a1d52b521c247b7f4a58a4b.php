<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <title>Телезапчасти</title>
    <meta name="description" content="Телезапчасти">
    <meta name="keywords" content="Телезапчасти">

    <!-- Headbase -->

    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <link rel="stylesheet" href="<?php echo e(URL::asset('css/flickity/flickity.css')); ?>">
    <script src="<?php echo e(URL::asset('js/flickity/flickity.js')); ?>"></script>

</head>

<body>
    <?php echo $__env->make('includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="slider-full">
        <div class="carousel" data-flickity='{ "contain": true, "prevNextButtons": false, "pageDots": false, "adaptiveHeight": true, "fade": true, "setGallerySize": false, "autoPlay": 3000 }'>
            <div class="carousel-cell">

            </div>
            <div class="carousel-cell">

            </div>
            <div class="carousel-cell">

            </div>
        </div>
    </div>
    <div class="features">
        <div class="features__item">
            <div class="features__item__wrapp">
                <div class="char_icon"><img src="<?php echo e(asset('img/icon/char_1.png')); ?>" alt="Запчасти для телевизоров, продать телевизор +на запчасти, телевизор скупка, телезапчасти"></div>
                <div class="char_content">
                    <h6>Free Delivery</h6>
                    <p>from 50&nbsp;&#x20bd;</p>
                </div>
            </div>
        </div>
        <div class="features__item">
            <div class="features__item__wrapp">
                <div class="char_icon"><img src="<?php echo e(asset('img/icon/char_2.png')); ?>" alt="Запчасти для телевизоров, продать телевизор +на запчасти, телевизор скупка, телезапчасти"></div>
                <div class="char_content">
                    <h6>Free Delivery</h6>
                    <p>from 50&nbsp;&#x20bd;</p>
                </div>
            </div>
        </div>
        <div class="features__item">
            <div class="features__item__wrapp">
                <div class="char_icon"><img src="<?php echo e(asset('img/icon/char_3.png')); ?>" alt="Запчасти для телевизоров, продать телевизор +на запчасти, телевизор скупка, телезапчасти"></div>
                <div class="char_content">
                    <h6>Free Delivery</h6>
                    <p>from 50&nbsp;&#x20bd;</p>
                </div>
            </div>
        </div>
        <div class="features__item">
            <div class="features__item__wrapp">
                <div class="char_icon"><img src="<?php echo e(asset('img/icon/char_4.png')); ?>" alt="Запчасти для телевизоров, продать телевизор +на запчасти, телевизор скупка, телезапчасти"></div>
                <div class="char_content">
                    <h6>Free Delivery</h6>
                    <p>from 50&nbsp;&#x20bd;</p>
                </div>
            </div>
        </div>
    </div>

    <div class="tab-card">
        <div class="tabs js-tabs">
            <ul role="tablist" class="tabs__tab-list">
                <li role="presentation">
                    <a href="#main" role="tab" aria-controls="main" class="tabs__trigger js-tab-trigger">Main Платы</a>
                </li>
                <li role="presentation">
                    <a href="#power" role="tab" aria-controls="power" class="tabs__trigger js-tab-trigger">Блоки питания</a>
                </li>
                <li role="presentation">
                    <a href="#led" role="tab" aria-controls="led" class="tabs__trigger js-tab-trigger">LED подсветки</a>
                </li>
            </ul>
            <div id="main" role="tabpanel" class="tabs__panel js-tab-panel">
                <div class="card">
                    <?php $__currentLoopData = $products_main; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card__item">
                        <div class="product__item <?php echo e($part->stock); ?>">
                            <div class="product_image">
                                <img src="/img/products/<?php echo e($part->company_id); ?>/<?php echo e($part->matrix_id); ?>/m<?php echo e($part->part_img_name); ?>" alt="Запчасти для телевизоров, <?php echo e($part->parttype_type); ?> <?php echo e($part->part_model); ?> c телевизора <?php echo e($part->company); ?> <?php echo e($part->tv_model); ?>">
                            </div>
                            <div class="product_content">
                                <div class="product_price">
                                    <h6>
                                        <?php echo e($part->part_cost); ?>&nbsp;&#x20bd;
                                        <span><?php echo e($part->price); ?></span>
                                    </h6>
                                </div>
                                <div class="product_name">
                                    <p><?php echo e($part->company); ?> <?php echo e($part->tv_model); ?></p>
                                    <a href="#"><?php echo e($part->part_model); ?></a>
                                </div>
                                <div class="product_extras">
                                    <button class="product_cart_button">
                                        <img src="<?php echo e(asset('img/icon/shopping-bag.svg')); ?>" alt="Купить">
                                    </button>
                                </div>
                            </div>
                            <ul class="product_marks">
                                <li class="product_marks__item product_discount">-<?php echo e($part->percent); ?>%</li>
                                <li class="product_marks__item product_new">new</li>
                            </ul>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>
            <div id="power" role="tabpanel" class="tabs__panel js-tab-panel">
                <div class="card">
                    <?php $__currentLoopData = $products_power; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card__item">
                        <div class="product__item <?php echo e($part->stock); ?>">
                            <div class="product_image">
                                <img src="/img/products/<?php echo e($part->company_id); ?>/<?php echo e($part->matrix_id); ?>/m<?php echo e($part->part_img_name); ?>" alt="Запчасти для телевизоров, <?php echo e($part->parttype_type); ?> <?php echo e($part->part_model); ?> c телевизора <?php echo e($part->company); ?> <?php echo e($part->tv_model); ?>">
                            </div>
                            <div class="product_content">
                                <div class="product_price">
                                    <h6>
                                        <?php echo e($part->part_cost); ?>&nbsp;&#x20bd;
                                        <span><?php echo e($part->price); ?></span>
                                    </h6>
                                </div>
                                <div class="product_name">
                                    <p><?php echo e($part->company); ?> <?php echo e($part->tv_model); ?></p>
                                    <a href="#"><?php echo e($part->part_model); ?></a>
                                </div>
                                <div class="product_extras">
                                    <button class="product_cart_button">
                                        <img src="<?php echo e(asset('img/icon/shopping-bag.svg')); ?>" alt="Купить">
                                    </button>
                                </div>
                            </div>
                            <ul class="product_marks">
                                <li class="product_marks__item product_discount">-<?php echo e($part->percent); ?>%</li>
                                <li class="product_marks__item product_new">new</li>
                            </ul>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div id="led" role="tabpanel" class="tabs__panel js-tab-panel">
                <div class="card">
                    <?php $__currentLoopData = $products_led; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card__item">
                        <div class="product__item <?php echo e($part->stock); ?>">
                            <div class="product_image">
                                <img src="/img/products/<?php echo e($part->company_id); ?>/<?php echo e($part->matrix_id); ?>/m<?php echo e($part->part_img_name); ?>" alt="Запчасти для телевизоров, <?php echo e($part->parttype_type); ?> <?php echo e($part->part_model); ?> c телевизора <?php echo e($part->company); ?> <?php echo e($part->tv_model); ?>">
                            </div>
                            <div class="product_content">
                                <div class="product_price">
                                    <h6>
                                        <?php echo e($part->part_cost); ?>&nbsp;&#x20bd;
                                        <span><?php echo e($part->price); ?></span>
                                    </h6>
                                </div>
                                <div class="product_name">
                                    <p><?php echo e($part->company); ?> <?php echo e($part->tv_model); ?></p>
                                    <a href="#"><?php echo e($part->part_model); ?></a>                                    
                                </div>
                                <div class="product_extras">
                                    <button class="product_cart_button">
                                        <img src="<?php echo e(asset('img/icon/shopping-bag.svg')); ?>" alt="Купить">
                                    </button>
                                </div>
                            </div>
                            <ul class="product_marks">
                                <li class="product_marks__item product_discount">-<?php echo e($part->percent); ?>%</li>
                                <li class="product_marks__item product_new">new</li>
                            </ul>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <div class="hot">
        <div class="hot__caption">
            <h4>Горячее предложение</h4>
        </div>
        <div class="card">
            <?php $__currentLoopData = $products_discount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card__item__np <?php echo e($part->stock); ?>">
                <div class="np__image">
                    <img src="/img/products/<?php echo e($part->company_id); ?>/<?php echo e($part->matrix_id); ?>/m<?php echo e($part->part_img_name); ?>" alt="Запчасти для телевизоров, <?php echo e($part->parttype_type); ?> <?php echo e($part->part_model); ?> c телевизора <?php echo e($part->company); ?> <?php echo e($part->tv_model); ?>">
                </div>
                <div class="np__content">
                        <p><?php echo e($part->company); ?> <?php echo e($part->tv_model); ?></p>
                        <a href="#"><?php echo e($part->part_model); ?></a>
                    <h6>
                        <?php echo e($part->part_cost); ?>&nbsp;&#x20bd;
                        <span><?php echo e($part->price); ?>&nbsp;&#x20bd;</span>
                    </h6>
                </div>
                <ul class="product_marks">
                    <li class="product_marks__item product_new">new</li>
                    <li class="product_marks__item product_discount">-<?php echo e($part->percent); ?>%</li>
                </ul>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="hot new">
        <div class="hot__caption">
            <h4>Новые поступления</h4>
        </div>
        <div class="card">
            <?php $__currentLoopData = $products_new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card__item__np <?php echo e($part->stock); ?>">
                <div class="np__image">
                    <img src="/img/products/<?php echo e($part->company_id); ?>/<?php echo e($part->matrix_id); ?>/m<?php echo e($part->part_img_name); ?>" alt="Запчасти для телевизоров, <?php echo e($part->parttype_type); ?> <?php echo e($part->part_model); ?> c телевизора <?php echo e($part->company); ?> <?php echo e($part->tv_model); ?>">
                </div>
                <div class="np__content">
                    <p><?php echo e($part->company); ?> <?php echo e($part->tv_model); ?></p>
                    <a href="#"><?php echo e($part->part_model); ?></a>
                    <h6>
                        <?php echo e($part->part_cost); ?>&nbsp;&#x20bd;
                        <span><?php echo e($part->price); ?>&nbsp;&#x20bd;</span>
                    </h6>
                </div>
                <ul class="product_marks">
                    <li class="product_marks__item product_new">new</li>
                    <li class="product_marks__item product_discount">-<?php echo e($part->persent); ?>%</li>
                </ul>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="slider-full">
        <div class="carousel" data-flickity='{ "contain": true, "prevNextButtons": false, "pageDots": false, "adaptiveHeight": true, "fade": true, "setGallerySize": false, "autoPlay": 3000 }'>
            <div class="carousel-cell">

            </div>
            <div class="carousel-cell">

            </div>
            <div class="carousel-cell">

            </div>
        </div>
    </div>
    <div class="about">
        <div>
            <h1>
                <span>запчасти для телевизоров</span>
                Телезапчасти
            </h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
    </div>


    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH E:\telezapchasti\resources\views/welcome.blade.php ENDPATH**/ ?>