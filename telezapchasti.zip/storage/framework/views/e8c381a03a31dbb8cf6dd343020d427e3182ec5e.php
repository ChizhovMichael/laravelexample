<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <title>Каталог</title>
    <meta name="description" content="Каталог">
    <meta name="keywords" content="Каталог">

    <!-- Headbase -->

    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <link rel="stylesheet" href="<?php echo e(URL::asset('css/flickity/flickity.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/noUiSlider/noUiSlider.css')); ?>">
    <script src="<?php echo e(URL::asset('js/flickity/flickity.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('js/noUiSlider/noUiSlider.js')); ?>"></script>

</head>

<body>

    <?php echo $__env->make('includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="slider-full mini">
        <div class="carousel" data-flickity='{ "contain": true, "prevNextButtons": false, "pageDots": false, "adaptiveHeight": true, "fade": true, "setGallerySize": false, "autoPlay": 3000 }'>
            <div class="carousel-cell">

            </div>
            <div class="carousel-cell">

            </div>
            <div class="carousel-cell">

            </div>
        </div>
    </div>
    <div class="catalog">
        <div class="sorting">
            <div class="sorting__item">
                <input type="checkbox" id="product" checked />
                <label for="product">
                    Запчасти
                    <img src="<?php echo e(asset('img/icon/chevron-arrow-down.svg')); ?>" alt="arrow">
                </label>
                <ul>
                    <li>
                        <a href="#">Lorem ipsum</a>
                    </li>
                    <li>
                        <a href="#">Lorem ipsum</a>
                    </li>
                    <li>
                        <a href="#">Lorem ipsum</a>
                    </li>
                </ul>
            </div>
            <div class="sorting__item">
                <input type="checkbox" id="tv" checked />
                <label for="tv">
                    Бренд телевизора
                    <img src="<?php echo e(asset('img/icon/chevron-arrow-down.svg')); ?>" alt="arrow">
                </label>
                <ul>
                    <li>
                        <a href="#">Lorem ipsum</a>
                    </li>
                    <li>
                        <a href="#">Lorem ipsum</a>
                    </li>
                    <li>
                        <a href="#">Lorem ipsum</a>
                    </li>
                </ul>
            </div>
            <div class="sorting__item">
                <input type="checkbox" id="price" checked />
                <label for="price">
                    Цена
                    <img src="<?php echo e(asset('img/icon/chevron-arrow-down.svg')); ?>" alt="arrow">
                </label>
                <ul>
                    <li>
                        <div class="price">
                            <span id="from">500 &#x20bd;</span>
                            <span> - </span>
                            <span id="to">15 000 &#x20bd;</span>
                        </div>
                        <div class="multi-range">
                            <input id="min" type="range" min="0" max="100" value="0" step="0.0001" />
                            <input id="max" type="range" min="0" max="100" value="100" step="0.0001" />
                        </div>
                    </li>
                </ul>

            </div>
            <div class="sorting__item">
                <input type="checkbox" id="category" checked />
                <label for="category">
                    Категория
                    <img src="<?php echo e(asset('img/icon/chevron-arrow-down.svg')); ?>" alt="arrow">
                </label>
                <ul>
                    <li>
                        <a href="#">Новые поступления</a>
                    </li>
                    <li>
                        <a href="#">Акция</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="container">
            <div class="container__sorting">

                <!-- Сделать сортировку -->

                <div class="dropdown">
                    <div class="dropdown__list">
                        <img src="<?php echo e(asset('img/icon/chevron-arrow-down.svg')); ?>" alt="Запчасти для телевизоров, продать телевизор +на запчасти, телевизор скупка, телезапчасти">
                        <span class="dropdown_placeholder">
                            По названию
                        </span>
                        <ul class="dropdown__list__ul">
                            <li><a class="clc" href="#">По цене</a></li>
                            <li><a class="clc" href="#">Main платы</a></li>
                            <li><a class="clc" href="#">Блоки питания</a></li>
                            <li><a class="clc" href="#">T-CON</a></li>
                            <li><a class="clc" href="#">Инверторы/LED драйверы</a></li>
                            <li><a class="clc" href="#">LED подсветка</a></li>
                            <li><a class="clc" href="#">Другое</a></li>
                        </ul>
                    </div>
                </div>

                
            </div>
            <div class="card">
                <div class="card__item shop">
                    <div class="product__item">
                        <div class="product_image">
                            <img src="<?php echo e(asset('img/m1513630340d.jpg')); ?>" alt="Запчасти для телевизоров, название товара + артикул">
                        </div>
                        <div class="product_content">
                            <div class="product_price">
                                <h6>
                                    379&nbsp;&#x20bd;
                                    <span></span>
                                </h6>
                            </div>
                            <div class="product_name">
                                <p>lorem ipsum</p>
                                <a href="#">Sony MDRZX310W</a>
                            </div>
                            <div class="product_extras">
                                <button class="product_cart_button">
                                    <img src="<?php echo e(asset('img/icon/shopping-bag.svg')); ?>" alt="Запчасти для телевизоров, название товара + артикул">
                                </button>
                            </div>
                        </div>
                        <ul class="product_marks">
                            <li class="product_marks__item product_discount">-25%</li>
                            <li class="product_marks__item product_new">new</li>
                        </ul>
                    </div>
                </div>
                <div class="card__item shop">
                    <div class="product__item">
                        <div class="product_image">
                            <img src="<?php echo e(asset('img/m1513630340d.jpg')); ?>" alt="Запчасти для телевизоров, название товара + артикул">
                        </div>
                        <div class="product_content">
                            <div class="product_price">
                                <h6>
                                    379&nbsp;&#x20bd;
                                    <span></span>
                                </h6>
                            </div>
                            <div class="product_name">
                                <p>lorem ipsum</p>
                                <a href="#">Sony MDRZX310W</a>
                            </div>
                            <div class="product_extras">
                                <button class="product_cart_button">
                                    <img src="<?php echo e(asset('img/icon/shopping-bag.svg')); ?>" alt="Запчасти для телевизоров, название товара + артикул">
                                </button>
                            </div>
                        </div>
                        <ul class="product_marks">
                            <li class="product_marks__item product_discount">-25%</li>
                            <li class="product_marks__item product_new">new</li>
                        </ul>
                    </div>
                </div>
                <div class="card__item shop">
                    <div class="product__item">
                        <div class="product_image">
                            <img src="<?php echo e(asset('img/m1513630340d.jpg')); ?>" alt="Запчасти для телевизоров, название товара + артикул">
                        </div>
                        <div class="product_content">
                            <div class="product_price">
                                <h6>
                                    379&nbsp;&#x20bd;
                                    <span></span>
                                </h6>
                            </div>
                            <div class="product_name">
                                <p>lorem ipsum</p>
                                <a href="#">Sony MDRZX310W</a>
                            </div>
                            <div class="product_extras">
                                <button class="product_cart_button">
                                    <img src="<?php echo e(asset('img/icon/shopping-bag.svg')); ?>" alt="Запчасти для телевизоров, название товара + артикул">
                                </button>
                            </div>
                        </div>
                        <ul class="product_marks">
                            <li class="product_marks__item product_discount">-25%</li>
                            <li class="product_marks__item product_new">new</li>
                        </ul>
                    </div>
                </div>
                <div class="card__item shop">
                    <div class="product__item">
                        <div class="product_image">
                            <img src="<?php echo e(asset('img/m1513630340d.jpg')); ?>" alt="Запчасти для телевизоров, название товара + артикул">
                        </div>
                        <div class="product_content">
                            <div class="product_price">
                                <h6>
                                    379&nbsp;&#x20bd;
                                    <span></span>
                                </h6>
                            </div>
                            <div class="product_name">
                                <p>lorem ipsum</p>
                                <a href="#">Sony MDRZX310W</a>
                            </div>
                            <div class="product_extras">
                                <button class="product_cart_button">
                                    <img src="<?php echo e(asset('img/icon/shopping-bag.svg')); ?>" alt="Запчасти для телевизоров, название товара + артикул">
                                </button>
                            </div>
                        </div>
                        <ul class="product_marks">
                            <li class="product_marks__item product_discount">-25%</li>
                            <li class="product_marks__item product_new">new</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH G:\telezapchasti\resources\views/page/shop.blade.php ENDPATH**/ ?>