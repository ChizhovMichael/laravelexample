<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($row->id); ?></td>
    <td><?php echo e($row->part_model); ?></td>
    <td><?php echo e($row->part_cost); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td colspan="3" align="center">
        <?php echo $data->links(); ?>

    </td>
</tr><?php /**PATH E:\telezapchasti\resources\views/pagination_data.blade.php ENDPATH**/ ?>